import api from "./api";
import { API_ENDPOINTS } from "@/lib/constants";

const IMPORT_RESPONSE_STATUS = new Set([200, 201, 400, 422]);

const postImportFile = async (endpoint, file) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await api.post(endpoint, formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
    validateStatus: (status) => IMPORT_RESPONSE_STATUS.has(status),
  });

  return response.data;
};

export const importStudents = async (file) => {
  return postImportFile(API_ENDPOINTS.IMPORT_STUDENTS, file);
};

export const importTeachers = async (file) => {
  return postImportFile(API_ENDPOINTS.IMPORT_TEACHERS, file);
};

export const importSessions = async (file) => {
  return postImportFile(API_ENDPOINTS.IMPORT_SESSIONS, file);
};
